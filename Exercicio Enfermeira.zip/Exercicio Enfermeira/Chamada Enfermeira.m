//
//  Chamada Enfermeira.m
//  Exercicio Enfermeira
//
//  Created by Usuário Convidado on 25/02/19.
//  Copyright © 2019 Thiago. All rights reserved.
//

#import "Chamada Enfermeira.h"

@implementation Chamada_Enfermeira

@end
