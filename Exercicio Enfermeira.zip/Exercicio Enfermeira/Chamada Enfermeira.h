//
//  Chamada Enfermeira.h
//  Exercicio Enfermeira
//
//  Created by Usuário Convidado on 25/02/19.
//  Copyright © 2019 Thiago. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Chamada_Enfermeira : NSObject{
    
    NSString *nome;
    int idade;
    Boolean turno;
    float salario;
    
    
    
    
}

@end

NS_ASSUME_NONNULL_END
