//
//  Atleta.m
//  Exemplo Classe 2TDSA
//
//  Created by Usuário Convidado on 25/02/19.
//  Copyright © 2019 Thiago. All rights reserved.
//

#import "Atleta.h"

@implementation Atleta

-(void)setNome: (NSString *)_nome{
    nome=_nome;
}
-(NSString * )getNome{
    return nome;
    
}

-(void)setIdade: (int)_idade{
     idade=_idade;
}
-(int )getIdade{
     return idade;
}

-(void)calcularImccomPeso:(float) peso
                  eAltura:(float) altura {
    
    float imc;
    imc=peso/(altura* altura);
    NSLog(@"O IMC do Atleta %@ é %0.2f",[self getNome], imc );
}

-(NSString *)calcularRendimentoComDistanciaEmMetros: (float) metros
                                      eTempoEmHoras: (float) tempo{
    
    float rendimento;
    rendimento = metros/tempo;
    NSString *texto=[NSString stringWithFormat:@"O Atleta possui rendimento de %0.2f metros por hora na água", rendimento ] ;
    return texto;
}

-(Atleta*)initWithNome: (NSString*)_nome andIdade: (int)_idade{
    self = [super init];
    [self setNome:_nome];
    [self setIdade:_idade];
    return self;
}


@end
