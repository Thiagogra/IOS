//
//  ViewController.m
//  Aula3 Action e Outlet
//
//  Created by Usuário Convidado on 25/02/19.
//  Copyright © 2019 Thiago. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}


@end
